package md.userserviceback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserservicebackApplicationTests {

	@Test
	void contextLoads() {
	}

}
