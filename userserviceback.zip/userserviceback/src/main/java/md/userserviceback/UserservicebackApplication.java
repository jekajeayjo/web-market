package md.userserviceback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserservicebackApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserservicebackApplication.class, args);
	}

}
